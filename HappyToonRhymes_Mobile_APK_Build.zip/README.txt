# Happy Toon Rhymes - Android Studio Project

This project wraps the supplied Happy Toon Rhymes HTML app in an Android WebView.

## Build an APK
1. Open Android Studio on a computer.
2. Choose **Open** and select this project folder.
3. Wait for Gradle sync to finish.
4. Select **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. Android Studio will show the APK location when the build finishes.

The app currently includes the rhymes and features from the supplied HTML file.
AdMob is not included yet. Add and test ads only after the app is working and you have an AdMob account/ad unit IDs.

## Build from an Android phone using GitHub Actions
1. Create a GitHub repository named HappyToonRhymes.
2. Upload all files and folders from this project (including the hidden .github folder).
3. Open the repository's Actions tab.
4. Select "Build Happy Toon Rhymes APK" and tap "Run workflow" if it has not started automatically.
5. When the run finishes, open it and download the artifact named "HappyToonRhymes-debug-apk".
6. Extract the artifact ZIP; it contains app-debug.apk.

This is a debug APK for testing, not a Play Store release build. No AdMob ads are included.
